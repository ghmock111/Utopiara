import { create } from "zustand";
import Cookies from "js-cookie";

type TermsStore = {
  isModalOpen: boolean;
  acceptTerms: () => void;
  openTerms: () => void;
  closeModal: () => void;
};

export const useTermsStore = create<TermsStore>((set) => ({
  isModalOpen: false, // Show modal if terms are not accepted
  acceptTerms: () => {
    Cookies.set("termsAccepted", "true", { expires: 365 }); // Store the acceptance for 1 year
    set({ isModalOpen: false }); // Close the modal when terms are accepted
  },
  openTerms: () => set({ isModalOpen: true }), // Manually open the terms modal
  closeModal: () => set({ isModalOpen: false }), // Close the terms modal
}));
